import React from 'react';

export default function About() {
  return <p>This is About</p>;
}

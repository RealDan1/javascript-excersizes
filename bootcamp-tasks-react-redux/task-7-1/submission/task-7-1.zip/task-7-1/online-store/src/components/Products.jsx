import React from 'react';

export default function Products() {
  return <p>This is Products</p>;
}

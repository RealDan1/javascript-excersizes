import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Balance from './components/Balance';
function App() {
  return (
    <div>
      <Balance />
    </div>
  );
}

export default App;

import React from 'react';

export default function Greetings() {
    return (
        <div>
            <p>Hello World</p>
        </div>
    );
}
